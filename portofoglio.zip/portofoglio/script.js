// Toggle Dark Mode
const toggleDark = document.getElementById("toggle-dark");
const body = document.body;

toggleDark.addEventListener("click", () => {
    body.classList.toggle("dark-mode");

    

    // Cambia l'icona del toggle
    if (body.classList.contains("dark-mode")) {
        toggleDark.innerHTML = "☀️"; // Modalità chiara
    } else {
        toggleDark.innerHTML = "🌙"; // Modalità scura
    }
});

// Animazioni Smooth Scroll per i link
const menuLinks = document.querySelectorAll("#menu a");

menuLinks.forEach((link) => {
    link.addEventListener("click", (e) => {
        e.preventDefault();
        const targetId = link.getAttribute("href").substring(1);
        const targetElement = document.getElementById(targetId);

        window.scrollTo({
            top: targetElement.offsetTop - 50,
            behavior: "smooth",
        });
    });
});

// Formulazione dinamica di immagini animate
const works = document.querySelectorAll(".work");

works.forEach((work) => {
    work.addEventListener("mouseover", () => {
        work.style.transform = "scale(1.1)";
        work.style.transition = "transform 0.3s ease-in-out";
    });

    work.addEventListener("mouseout", () => {
        work.style.transform = "scale(1)";
    });
});
// Invia i dati del modulo al Google Sheets
const form = document.querySelector("#contact-form");

form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const formData = new FormData(form);

    try {
        const response = await fetch("https://api.sheetson.com/v2/sheets/YOUR_GOOGLE_SHEET_ID", {
            method: "POST",
            body: JSON.stringify({
                Nome: formData.get("name"),
                Email: formData.get("email"),
                Messaggio: formData.get("message"),
            }),
            headers: {
                "Content-Type": "application/json",
                Authorization: "Bearer YOUR_API_KEY",
            },
        });

        if (response.ok) {
            alert("Messaggio inviato con successo!");
            form.reset();
        } else {
            alert("Errore nell'invio del messaggio.");
        }
    } catch (error) {
        console.error("Errore:", error);
        alert("Errore di rete.");
    }
});